#include <stdio.h>
#include "lectura.h"
#include "Practica1.h"

int main(){
	sequencia1();
	sequencia2();
	sequencia3();
	sequencia4();
	sequencia5();
	sequencia6();
	int asterisco = readint();
	asteriscs(asterisco);
	int a�o = readint();
	antytraspas(a�o);
	printf("\nLa hora:");
	int hora = readint();
	printf("\nMinutos:");
	int minuts = readint();
	printf("\nSegundos:");
	int segons = readint();
	nextsecond(hora, minuts, segons);
	

}
void sequencia1(){
	printf("sequencia1: ");
	int numero = 1;
	while (numero <= 10){
		printf("%d ", numero);
		numero = numero + 1;
	}
}

void sequencia2(){
	printf("\nsequencia2: ");
	int numero = 2;
	while (numero <= 20){
		printf("%d ", numero);
		numero = numero + 2;
	}
}

void sequencia3(){
	printf("\nsequencia3: ");
	int numero = 20;
	while (numero <= 38){
		printf("%d ", numero);
		numero = numero + 2;
	}
}

void sequencia4(){
	printf("\nsequencia4: ");
	int numero = 10;
	while (numero <= 46){
		printf("%d ", numero);
		numero = numero + 4;
	}
}

void sequencia5(){
	printf("\nsequencia5: ");
	int numero = 45;
	while (numero >= 0) {
		printf("%d ", numero);
		numero = numero - 5;
	}
}

void sequencia6(){
	printf("\nsequencia6: ");
	int numero = 7;
	while (numero <= 34){
		printf("%d ", numero);
		numero = numero + 3;
	}
	printf("\n\n");
}


void asteriscs(int asterisco){
	int numast = 1;
	while (numast <= asterisco){
		int petit = 0;
		petit = 0;
		while (petit < numast){
			printf("*");
			petit++;
		}
		numast++;
		printf("\n");
	}
	printf("\n");
}


void antytraspas(int a�o){
	if (a�o % 4 != 0){
		printf("No es bisiesto");
	}
	if (a�o % 4 == 0){
		if (a�o < 400){
			printf("Es bisiesto");
		}
		if (a�o > 400){
			if (a�o % 400 == 0){
				printf("Es bisiesto");

			}
			if (a�o % 100 != 0){
				printf("Es bisiesto");
			}
			if (a�o % 4 == 0 && a�o > 100 && a�o % 100 == 0 && a�o % 400 != 0){
				printf("No es bisiesto");
			}
		}

	}
	printf("\n");
}

void nextsecond(int hora, int minuts, int segons){
	segons++;
	if (segons > 59){
		minuts++;
		segons = 00;
		if (minuts > 59){
			hora++;
			minuts = 00;
		}
		if (hora>23){
			hora = 00;
			minuts = 00;
			segons = 00;
		}
	}
	printf("\nLa hora(un segon despr�s) es : %02d:%02d:%02d\n", hora, minuts, segons);



}