void sequencia1();
void sequencia2();
void sequencia3();
void sequencia4();
void sequencia5();
void sequencia6();
void asteriscs(int asterisco);
void antytraspas(int a�o);
void nextsecond(int hora, int minuts, int segons);