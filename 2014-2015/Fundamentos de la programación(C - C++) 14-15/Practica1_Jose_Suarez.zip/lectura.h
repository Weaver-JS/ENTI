#include <iostream>
using namespace std;

int readint()
{
	int numero;
	cin >> numero;
	return numero;
}

float readfloat()
{
	float numero;
	cin >> numero;
	return numero;
}

char readchar()
{
	char caracter;
	cin >> caracter;
	return caracter;
}