%Jose Su�rez Weaver, Aleix Parellada
clear all;
%A=round(rand(80,80));
A=zeros(40); 
A(1,:)=0;
A(40,:)=0;
A(:,1)=0;
A(:,40)=0;
A(6:2:36,6:1:30) = 1;
Generacio=1;
spy(A)
pause (1)

while Generacio<=10
B=A;
tini=cputime 
i=2;
Generacio=Generacio
while(i<40)
j=2;
    while(j<40)
      vecinos = (A(i,j+1) + A(i-1,j) + A(i+1,j) + A(i,j-1) + A(i+1,j+1) + A(i+1,j-1) + A(i-1,j+1) + A(i-1,j-1));
%      if (A(i,j) == 1)
%        if(vecinos < 2)
%          B(i,j)=0;
       
       if(vecinos > 3)
          B(i,j)=0;
        end
      %end  
      if(A(i,j) == 0)
        if(vecinos == 3)
          B(i,j)=1;
        end
      end
     j= j+1;
    end
   i= i+1;
  end
 A = B;
 spy (A) 
 pause (1);
Generacio = Generacio + 1;
A(18,12)
A(18,22)
A(23,12)
A(23,22)
tfin=cputime-tini
end



