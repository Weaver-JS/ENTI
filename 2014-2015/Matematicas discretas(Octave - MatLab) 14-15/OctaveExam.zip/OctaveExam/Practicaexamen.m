clear all;
x= load ('alumnesENTI.txt'); %carrega archivo de dades
Nx= size(x,1); %Calcula el numero de dades en la columna 1
Nx
Peso = x(:,2); % crea una columna con todas las dades de la columna dos que es el sexo
sexe = x(:,3);

iy=find(sexe>0); % buscamos los hombres que son inferiores a 2 y los pone en una vector nuevo
Homes=size(iy,1); % imprimimos el tama�o del vecto que es la cantidad de hombres

%iy=find(sexe>1); % buscamos los hombres que son superiores a 1 y los pone en una vector nuevo
%Dones=size(iy,1) % imprimimos el tama�o del vecto que es la cantidad de mujeres
Dones = Nx - Homes;
Homes = Homes / Nx * 100
Dones = Dones / Nx * 100


%Activitats = x(:,3); %creo un vector con los datos de la columna tres del txt que me dan
Tipustransport = x(:,5);

% SI ES CONTINUA TENEMOS QUE ESTABLECER NOSOTROS LOS INTERVALOS 
Nx= size(x,5);  % COGEMOS LA COLUMNA QUE QUEREMOS USAR
ndiv=ceil(sqrt(Nx)); %CREAMOS LOS INTERVALOS
[nn,xx] = hist(Tipustransport,ndiv); % CREAMOS UN HISTOGRAMA PARA PODER HACER LAS TABLAS
taula = [xx', nn'];
taula = [taula,100*taula(:,2)/Nx]; % afagir columna de freq. relativa
taula = [taula,cumsum(taula(:,2))]; %afagir columna de Freq. Abs. Acumulada
taula = [taula,cumsum(taula(:,3))]%afagir columna de Freq. Rel. Acumulada



 % SI ES DISCRETA PUEDO HACERLO CON ESTO PERO PONIENDO LOS INTERVALOS ADECUADOS
%taula = tabulate(Activitats);
taula = tabulate(Tipustransport,[0, 1, 2, 3,4,5,6]); % creo una tabla de frencuencias de la columna 3 con los intervalos 0,1,2,3,4,5,6
taula=[taula,cumsum(taula(:,3))] %a�ado la columna de frecuencia relativa acumulada


TV = x(:,4);
%taula2 = tabulate(Tipustransport[0,1,2,3,4,5,6]);
%taula3 = tabulate(sexe,[0,1])
%taula = tabulate (TV);
%taula=[taula,cumsum(taula(:,3))]

maxim=max(TV)  % dada de valor minim
minim=min(TV)  % dada de vakir maxim
rang=maxim-minim % diferencia
mitjana=mean(TV)  %valor medio = suma de todos los valores dividio el numero de valores
mediana = median(TV);  % valor que se encuentra en el punto medio de la tabla
moda=mode(TV) % valor que mas se repite
desviacio=std(TV)
variancia=var(TV)
Q1=prctile(TV,25)
Q2=prctile(TV,50)
Q3=prctile(TV,75)
IQR=Q3-Q1  % Rang interquartilic


%CALCULAR OUTLIERS

y=sort(TV);
dist=1.1;

iy=find(y<Q1-dist*IQR);
if (length(iy)>0)
  outliersQ1=y(iy)
else
  outliersQ1=[]
end

iy=find(y>Q3+dist*IQR);
if(length(iy)>0)
  outliersQ3=y(iy)
else
  outliersQ3=[];
end
%pkg load estatistics