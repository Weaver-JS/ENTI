clear all
close all

A=load('nivell.txt','-ascii');
[m,n]=size(A);

pintaScene(A);
% Goal
    %igoal = 42; jgoal = 40;
    igoal = 10; jgoal = 8;
    if (A(igoal,jgoal) == 0)
        pintaCella(jgoal,igoal,'r') %noteu que pintem la cel�la (j,i)
                                     %perque el dibuix sigui intuitiu 
    else
        disp('Bad goal');
        return;
    end
    
% Initial    
    %iini = 2; jini = 20;
    iini = 1; jini = 3;
    if (A(iini,jini) == 0)
        pintaCella(jini,iini,'g');  %pintem en verd la cel�la inicial
    else
        disp('Bad inicialization');
        return;
    end
% Inicialment A(i,j) sempre �s 0 o 1 segons la cel�la sigui o no obstacle
% Cada vegada que passem per una cel�la posarem el valor a 2.
% Aix� per pas inicial farem
i = iini;
j= jini;


x = 0;


while( x != 1)

  if( i== igoal & j == jgoal)
    x = 1;

    pintaCella(jgoal,igoal,'r')
  else

    A(i,j) = 2;
    costIni = 2;
   if( A(i+1,j) != 11)
    N =  A(i+1,j);
   else
    N = 1
  end
  if (i-1 > 0)
    S =  A(i-1,j);
   else
    S = 1
  end
    E =  A(i,j+1); 
    W =  A(i,j-1);
  if (i-1 > 0)  
    Nw = A(i-1,j+1);
    else
    Nw = 1;
  end
    Ne = A(i+1,j+1);
    Se = A(i+1,j-1);
  if ( i-1 > 0)
    Sw = A(i-1,j-1);
   else
      Sw = 1;
  end
    



     
     if( N == 0 )
       dN = 10;
     else
       dN = 10000;
     end
     if ( S == 0 )
       dS = 10;
      else 
       dS = 10000;
      end
     if ( E == 0 )
       dE = 10;
      else
       dE = 10000;
     end
     if ( W == 0 )
       dW = 10;
      else
       dW = 10000;
      end
      
     if ( Nw == 0 )
       dNw = 10*sqrt(2);
      else
       dNw = 10000;
     end
     if ( Se == 0) 
       dSe = 10;%10*sqrt(2);
      else 
       dSe = 10000;
      end
     if ( Ne == 0)
       dNe = 10;%10*sqrt(2);
      else
       dNe = 10000;
     end
     if ( Sw == 0) 
       dSw = 10*sqrt(2);
      else
       dSw = 10000;
      end
      
     %Cost de mov. a cada cela
     
%      Mh1 = dN*abs(i-igoal) + dN*abs(j-jgoal)
%      Mh2 = dS*abs(i-igoal) + dS*abs(j-jgoal)
%      Mh3 = dE*abs(i-igoal) + dE*abs(j-jgoal)
%      Mh4 = dW*abs(i-igoal) + dW*abs(j-jgoal)
%      
%      Mh5 = dNe*abs(i-igoal) + dNe*abs(j-jgoal)
%      Mh6 = dNw*abs(i-igoal) + dNw*abs(j-jgoal)
%      Mh7 = dSe*abs(i-igoal) + dSe*abs(j-jgoal)
%      Mh8 = dSw*abs(i-igoal) + dSw*abs(j-jgoal)


      Mh1 = dN*abs((i+1)-igoal) + dN*abs(j-jgoal);
      Mh2 = dS*abs((i-1)-igoal) + dS*abs(j-jgoal);
      Mh3 = dE*abs(i-igoal) + dE*abs((j+1)-jgoal);
      Mh4 = dW*abs(i-igoal) + dW*abs((j-1)-jgoal);
      
      Mh5 = dNe*abs((i+1)-igoal) + dNe*abs((j+1)-jgoal);
      Mh6 = dNw*abs((i-1)-igoal) + dNw*abs((j+1)-jgoal);
      Mh7 = dSe*abs((i+1)-igoal) + dSe*abs((j-1)-jgoal);
      Mh8 = dSw*abs((i-1)-igoal) + dSw*abs((j-1)-jgoal);
      
      Mh1mod = Mh1 + (10*sqrt(2) - 2*10) * min (abs((i+1)-igoal),abs(j-jgoal));
      Mh2mod = Mh2 + (10*sqrt(2) - 2*10) * min (abs((i-1)-igoal),abs(j-jgoal));
      Mh3mod = Mh3 + (10*sqrt(2) - 2*10) * min (abs(i-igoal),abs((j+1)-jgoal));
      Mh4mod = Mh4 + (10*sqrt(2) - 2*10) * min (abs(i-igoal),abs((j-1)-jgoal));
      
      Mh5mod = Mh5 + (10*sqrt(2) - 2*10) * min (abs((i+1)-igoal),abs((j+1)-jgoal));
      Mh6mod = Mh6 + (10*sqrt(2) - 2*10) * min (abs((i-1)-igoal),abs((j+1)-jgoal));
      Mh7mod = Mh7 + (10*sqrt(2) - 2*10) * min (abs((i+1)-igoal),abs((j-1)-jgoal));
      Mh8mod = Mh8 + (10*sqrt(2) - 2*10) * min (abs((i-1)-igoal),abs((j-1)-jgoal));
       
      %valor = abs( sqrt( ((igoal - x )* (igoal-x)) + (( y-jgoal)*(y-jgoal))))
      
      
      c1 = 10 + Mh1mod + costIni;
      c2 = 10 + Mh2mod + costIni;
      c3 = 10 + Mh3mod + costIni;
      c4 = 10 + Mh4mod + costIni;
     
      c5 = 10 + Mh5mod + costIni;
      c6 = 10 + Mh6mod + costIni;
      c7 = 10 + Mh7mod + costIni;
      c8 = 10 + Mh8mod + costIni;
   



%trampa
   
%      valor1 = abs( sqrt( ((igoal - i )* (igoal-i)) + (( (j+1)-jgoal)*((j+1)-jgoal))))
%      valor2 = abs( sqrt( ((igoal - i )* (igoal-i)) + (( (j-1)-jgoal)*((j-1)-jgoal))))
%      valor3 = abs( sqrt( ((igoal - (i+1) )* (igoal-(i+1))) + (( j-jgoal)*(j-jgoal))))
%      valor4 = abs( sqrt( ((igoal - (i-1) )* (igoal-(i-1))) + (( j-jgoal)*(j-jgoal))))
%      
%      valor5 = abs( sqrt( ((igoal - (i+1) )* (igoal-(i+1))) + (( (i+1)-jgoal)*((i+1)-jgoal))))
%      valor6 = abs( sqrt( ((igoal - (i-1) )* (igoal-(i-1))) + (( (i+1)-jgoal)*((i+1)-jgoal))))
%      valor7 = abs( sqrt( ((igoal - (i+1) )* (igoal-(i+1))) + (( (i-1)-jgoal)*((i-1)-jgoal))))
%      valor8 = abs( sqrt( ((igoal - (i-1) )* (igoal-(i-1))) + (( (i-1)-jgoal)*((i-1)-jgoal))))
%      
%      c1 = dN + valor1
%      c2 = dS + valor2
%      c3 = dE + valor3
%      c4 = dW + valor4
%     
%      c5 = dNe + valor5
%      c6 = dNw + valor6
%      c7 = dSe + valor7
%      c8 = dSw + valor8
         
     %Cost mes petit
     
       minim = c1;
       if (c5 < minim)
        minim = c5;
       end        
       if (c2 < minim)
        minim = c2;
       end
       if (c3 < minim)
        minim = c3 ;
       end
       if (c4 < minim)
        minim = c4;
       end

       if (c6 < minim)
        minim = c6;
       end
       
       if (c7 < minim)
        minim = c7;
        
       end
       if (c8 < minim)
        minim = c8;
       end
       
     %Actualitzar mov.
       %c1=N,c2=S,c3=E,c4=W,c5=Ne,c6=Nw,c7=Se,c8=Sw    
      if minim == c5
        i = i+1;
        j = j+1;
        minim = 0;   
      end
      if minim == c1
        i = i+1;
        minim = 0; 
      end   
      if minim == c3
        j = j + 1;
        minim = 0;
      end    
      if minim == c4
        j = j-1;
        minim = 0;
      end  
      if minim == c2
        i = i-1;
        minim = 0;
      end  

  
      if minim == c6
        i = i-1;
        j = j+1;
        minim = 0;
      end
      if minim == c7
        i = i+1;
        j = j-1;
        minim = 0;
      end
      if minim == c8
        i = i-1;
        j = j-1;
        minim = 0;
      end    
     %moviment i pintar
      pintaCella(j,i,'y')
      costIni = costIni+2;
      %Manhattan =
    end
end
