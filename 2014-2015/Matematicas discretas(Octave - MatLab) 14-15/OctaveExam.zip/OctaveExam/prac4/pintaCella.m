function pintaCella(i,j,color)
    X=[i,i,i+1,i+1,i]';
    Y=[j,j+1,j+1,j,j]';
    fill(X,Y,color);
end