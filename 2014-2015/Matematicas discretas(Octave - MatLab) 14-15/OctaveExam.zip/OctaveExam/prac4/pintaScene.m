function pintaScene(A)
[m,n]=size(A);
for i=1:m+1
    for j=1:n+1;
        line([i,n],[j,j]);
        line([i,i],[j,n]);
    end
end
axis([0,m+2,0,n+2])
hold on;
for i=1:m
    for j=1:n
        if (A(i,j)==1)
            pintaCella(j,i,'b');
        end
    end
end
axis equal;


