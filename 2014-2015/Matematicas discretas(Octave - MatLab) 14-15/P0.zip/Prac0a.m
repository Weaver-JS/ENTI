%Jose Suarez Weaver
%Aleix Parellada Molina
clear all ;
x = [1, 1000, 10000, 100000, 1000000]
r = 1
while r<6
[p,e] = epsilon (x(r))
r=r+1;
end
