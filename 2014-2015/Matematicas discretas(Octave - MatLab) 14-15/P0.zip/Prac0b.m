%Jose Suarez Weaver
%Aleix Parellada Molina
clear all;
tol = [10^(-4),10^(-6),10^(-8)];
r = 1;

while r<4
  tini=cputime
  n = harmonic (tol(r))
  tfin=cputime-tini
  tol(r)
  r=r+1;
  end