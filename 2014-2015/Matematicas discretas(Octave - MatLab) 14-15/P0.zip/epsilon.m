%Jose Suarez Weaver
%Aleix Parellada Molina
function [p,e] = epsilon (tol)
x = tol
p = 0
while x+2^(-p) ~= x
 p=p+1 ;
 end
 e = 2^(-p);