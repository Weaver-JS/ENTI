%Jose Suarez Weaver
%Aleix Parellada Molina
function n = harmonic (tol)
n = 2;
sum = 1 +( 1/n^(2));
while (abs (sum - ((pi^2/6)))) >=  tol
n = n+1;
sum = sum+1/n^2;
end
tol 