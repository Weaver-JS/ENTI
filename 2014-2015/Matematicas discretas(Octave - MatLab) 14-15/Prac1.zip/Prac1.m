%Jose Su�rez Weaver, Aleix Parellada
clear all;
A=round(rand(80,80)); 
A(1,:)=0;
A(80,:)=0;
A(:,1)=0;
A(:,80)=0;
Generacio=1;
spy(A)
pause (1)

while Generacio<=80
B=A;
tini=cputime 
i=2;
Generacio=Generacio
while(i<80)
j=2;
    while(j<80)
      vecinos = (A(i,j+1) + A(i-1,j) + A(i+1,j) + A(i,j-1));
      if (A(i,j) == 1)
        if(vecinos < 2)
          B(i,j)=0;
       
       elseif(vecinos> 3)
          B(i,j)=0;
        end
      end  
      if(A(i,j) == 0)
        if(vecinos == 3)
          B(i,j)=1;
        end
      end
     j= j+1;
    end
   i= i+1;
  end
 A = B;
 spy (A) 
 pause (1);
Generacio = Generacio + 1;
tfin=cputime-tini
end



