#include "Cloth.h"



Cloth::Cloth()
{
}


Cloth::~Cloth()
{
}
