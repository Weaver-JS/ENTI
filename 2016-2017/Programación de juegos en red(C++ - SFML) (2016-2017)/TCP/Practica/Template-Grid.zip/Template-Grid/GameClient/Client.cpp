#include "Client.h"



Client::Client(sf::RectangleShape & rect1, sf::RectangleShape & rect2) {
	idTurnInGame = -1;
	actualWord = "";
	player1 = &rect1;
	player2 = &rect2;
}


Client::~Client() {
	for (const PlayerInfo* e : enemies) {
		delete e;
	}
	enemies.clear();
}

bool Client::getP1Win()
{
	return player1win;
}

bool Client::getP2Win()
{
	return player2win;
}

bool Client::connect() {

	if (me.getSocket().connect(IP, PORT, sf::seconds(5.0f)) == sf::Socket::Done) {
		me.getSocket().setBlocking(false);
		cIsConnected = true;
		return true;
	}
	return false;
}

bool Client::isConnected() {
	return cIsConnected;
}

bool Client::sendMessage(std::string message) {
	std::cout << "sending: " << message << std::endl;
	sf::Socket::Status status = me.getSocket().send(message.c_str() ,sizeof(message), sent);
	std::size_t found;
	switch (status) {
	case sf::Socket::Done:
		std::cout << "done send " <<  std::endl;
		return true;
	case sf::Socket::Partial:
		message = message.substr(message.size() - sent, message.size() );
		sendMessage(message);
		break;
	default:
		std::cout << "sendMessage(): status " << status << std::endl;
		return false;
	}
	return false;
}

void Client::receive() {
	sf::Socket::Status status = me.getSocket().receive(buffer, sizeof(buffer), received);
	switch (status) {
	case sf::Socket::Partial:
	case sf::Socket::Error:
	case sf::Socket::Disconnected:
	case sf::Socket::NotReady:
		break;
	case sf::Socket::Done:
		std::cout << "received: " << buffer << std::endl;
		checkMessage(buffer);
	}
}

void Client::disconnect() {
	if (cIsConnected) {
		std::string message = std::to_string(Protocol::Disconnect) + 
			"_" + std::to_string(me.getId());
		std::cout << "disconnect " << message <<std::endl;

		if (sendMessage(message)) {
			me.getSocket().disconnect();
		}
	
		cIsConnected = false;
		for (int i = 0; i < enemies.size(); i++)
		{
			enemies[i]->getSocket().disconnect();
		}
		enemies.clear();
		
	}

}

void Client::draw(sf::RenderWindow* window) {

	me.draw(window);

	for (PlayerInfo* e : enemies) {
		e->draw(window);
	}
}

void Client::checkMessage(std::string received) {
		std::vector < std::string > message = Utils::splitString(received, '_');
	Protocol p = (Protocol)std::stoi(message.at(0));

	// HELLO_ID_POSX_POSY
	switch (p) {

	case Protocol::Win:
	{
		int receivedID = std::stoi(message.at(1));
		if (receivedID == 0)
		{
			player1win = true;
		}
		else
		{
			player2win = true;
		}

	}
		break;
	case Protocol::NiceJob:
	{
		
		int receivedID = std::stoi(message.at(1));
		
		if (receivedID == 0)
		{
			player1->setPosition(player1->getPosition().x + 40, player1->getPosition().y);
		}
		else
		{
			player2->setPosition(player2->getPosition().x + 40, player2->getPosition().y);
		}
	}
		break;
	case Protocol::Word:
		
		actualWord = message.at(1);
		std::cout << actualWord << std::endl;
		break;
	case Protocol::Hello:
	{
		me.setId(std::stoi(message.at(1)));
		switch (me.getId())
		{
		case 0:
			nickname = "Nick player 1";
			break;
		case 1:
			nickname = "Nick player 2";
			break;
		}
		std::cout << nickname << std::endl;
		sf::Vector2f newPos = sf::Vector2f(std::stoi(message.at(2)),
			std::stoi(message.at(3)));

		std::cout << "X: " << newPos.x << std::endl;

		std::cout << "Y: " << newPos.y << std::endl;
		me.setPosition(newPos);

		std::cout << "Id: " << message.at(1) << std::endl;
		me.blocking(false);
		if (me.getId() > 0)
		{
			
			sendMessage(std::to_string(Protocol::Start_Game));
		}
	}
		break;
	case Protocol::Disconnect:
		std::cout << "protocol- disconnect" << std::endl;
		disconnect();
		break;
	case Protocol::Position:		 
	{
		int enemyId = std::stoi(message.at(1));
		sf::Vector2f enemyPos = sf::Vector2f(std::stoi(message.at(2)),
								std::stoi(message.at(3)));

		// it's me, pass
		if (me.getId() == enemyId) {
			break;
		}
		// Check if we have the id 
		for (int i = 0; i < enemies.size(); i++) {
			if (enemies.at(i)->getId() == enemyId) {
				enemyId = -1;
				enemies.at(i)->setPosition(enemyPos);
			}
		}

		// if its -1, The enemy it's not in the vector
		if (enemyId != -1) {
			PlayerInfo* newEnemy = new PlayerInfo();
			newEnemy->setId(enemyId);
			newEnemy->setPosition(enemyPos);
			newEnemy->setColor(sf::Color::Blue);
			enemies.push_back(newEnemy);
		}
	}
	break;
	case Protocol::Start_Turn:
		idTurnInGame = std::stoi(message.at(1));
		std::cout << "Player in turn: "<< idTurnInGame << std::endl;
		if (me.getId() != idTurnInGame)
			moved = false;
		break;
	default:
		std::cout << "Default " << std::endl;
		break;
	}
}


// Game Methods
void Client::Move(Movements mv)
{
	moved = true;
	if (me.getId() == idTurnInGame) {
			switch (mv)
			{
				case Right:
					me.getPosition().x++;
				break;
		
				case Left:
					me.getPosition().x--;
				break;

				case Up:
					me.getPosition().y--;
				break;

				case Down:
					me.getPosition().y++;
				break;
			}
	
		//	me.setPosition(mousePos);

		std::string posMessage = std::to_string(Protocol::Position) +
			"_" + me.getPlayerInfo();


		sendMessage(posMessage);
		
	}
}

PlayerInfo & Client::getPlayerInfo()
{
	return me;
}

std::string & Client::getActualWOrd()
{
	return actualWord;
}

void Client::click(sf::Vector2f mousePos) {

	
	if (me.getId() == idTurnInGame) {
	//	me.setPosition(mousePos);
		
		std::string posMessage = std::to_string(Protocol::Position) +
			"_" + me.getPlayerInfo();
		sendMessage(posMessage);
	}
}