#ifndef _CLIENT
#define _CLIENT

#include <iostream>

#include <SFML/Network.hpp>
#include <PlayerInfo.h>
#define PORT 5000

class Client {
private:
	sf::IpAddress IP = sf::IpAddress::getLocalAddress();
	PlayerInfo me;
	std::string actualWord;
	std::vector<PlayerInfo*> enemies;

	sf::RectangleShape* player1;
	sf::RectangleShape* player2;
	bool cIsConnected = false;

	bool player1win = false, player2win = false;

	std::string nickname;
	std::size_t sent;
	std::size_t received;
	char buffer[2000];

	bool moved = false;
	


	int idTurnInGame;

public:
	Client(sf::RectangleShape & rect1,sf::RectangleShape & rect2);
	~Client();

	bool getP1Win();
	bool getP2Win();

	bool connect();

	bool isConnected();

	void disconnect();

	void draw(sf::RenderWindow* window);

	bool sendMessage(std::string message);

	void click(sf::Vector2f mousePos);
	void receive();
	void checkMessage(std::string received);
	void Move(Movements mv);

	PlayerInfo & getPlayerInfo();
	std::string & getActualWOrd();
};

#endif