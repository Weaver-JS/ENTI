#include <SFML\Graphics.hpp>
#include <string>
#include <iostream>
#include <vector>

#define MAX_MENSAJES 30

#include "Client.h"

void initInterface()
{

}

int main()
{
	bool gameOver = false;
	sf::RectangleShape rectPlayer1(sf::Vector2f(40, 40));
	rectPlayer1.setFillColor(sf::Color(255, 0, 0, 255));
	rectPlayer1.setPosition(200, 80);

	sf::RectangleShape rectPlayer2(sf::Vector2f(40, 40));
	rectPlayer2.setFillColor(sf::Color(0, 255, 0, 255));
	rectPlayer2.setPosition(200, 280);

			Client client(rectPlayer1, rectPlayer2);

			if (client.connect()) {
				std::cout << "connection established" << std::endl;
			}
			else {
				std::cout << "connection error, " << std::endl;
			}

		

		

	
		std::vector<std::string> aMensajes;

		sf::Vector2i screenDimensions(800, 600);

		sf::RenderWindow window;
		window.create(sf::VideoMode(screenDimensions.x, screenDimensions.y), "Chat");

		sf::Font font;
		if (!font.loadFromFile("courbd.ttf"))
		{
			std::cout << "Can't load the font file" << std::endl;
		}



		sf::String mensaje = ">";

		sf::Text txtPregunta("Pregunta de server", font, 14);
		
		
		txtPregunta.setFillColor(sf::Color(0, 160, 0));
		txtPregunta.setStyle(sf::Text::Bold);
		txtPregunta.setPosition(sf::Vector2f(0, 480));

		sf::Text txtPlayer1Nick("Nick P1", font, 20);
		txtPlayer1Nick.setFillColor(sf::Color(255, 255, 255));
		txtPlayer1Nick.setStyle(sf::Text::Bold);
		txtPlayer1Nick.setPosition(100, 100);

		sf::Text txtPlayer2Nick("Nick P2", font, 20);
		txtPlayer2Nick.setFillColor(sf::Color(255, 255, 255));
		txtPlayer2Nick.setStyle(sf::Text::Bold);
		txtPlayer2Nick.setPosition(100, 300);

		sf::Text text(mensaje, font, 14);
		text.setFillColor(sf::Color(0, 160, 0));
		text.setStyle(sf::Text::Bold);
		text.setPosition(0, 560);

		sf::RectangleShape pista1(sf::Vector2f(500, 5));
		pista1.setFillColor(sf::Color(0, 0, 255, 255));
		pista1.setPosition(200, 120);

		sf::RectangleShape pista2(sf::Vector2f(500, 5));
		pista2.setFillColor(sf::Color(0, 0, 255, 255));
		pista2.setPosition(200, 320);

		sf::RectangleShape separator1(sf::Vector2f(800, 5));
		separator1.setFillColor(sf::Color(200, 200, 200, 255));
		separator1.setPosition(0, 450);

		sf::RectangleShape separator2(sf::Vector2f(800, 5));
		separator2.setFillColor(sf::Color(200, 200, 200, 255));
		separator2.setPosition(0, 550);

		

		while (window.isOpen())
		{

			sf::Event evento;
			while (window.pollEvent(evento))
			{
				switch (evento.type)
				{
				case sf::Event::Closed:

					break;
				case sf::Event::KeyPressed:
					if (evento.key.code == sf::Keyboard::Escape)
					{
						client.disconnect();

						window.close();
					}
					else if (evento.key.code == sf::Keyboard::Return)
					{

						aMensajes.push_back(mensaje);
						mensaje.erase(0, 1);
						client.sendMessage(std::to_string(Protocol::Word) + "_"
							+ std::to_string(client.getPlayerInfo().getId()) + "_" + mensaje);

						if (aMensajes.size() > 25)
						{
							aMensajes.erase(aMensajes.begin(), aMensajes.begin() + 1);
						}
						mensaje = ">";
					}
					break;
				case sf::Event::TextEntered:
					if (evento.text.unicode >= 32 && evento.text.unicode <= 126)
						mensaje += (char)evento.text.unicode;
					else if (evento.text.unicode == 8 && mensaje.getSize() > 0)
						mensaje.erase(mensaje.getSize() - 1, mensaje.getSize());
					break;
				}
			}

			client.receive();
			txtPregunta.setString(client.getActualWOrd());

			if (!gameOver)
			{
				if (client.getPlayerInfo().getId() == 0)
				{
					if (rectPlayer1.getPosition().x >= pista1.getSize().x + 200)
					{
						client.sendMessage(std::to_string(Protocol::Win) + "_"
							+ std::to_string(client.getPlayerInfo().getId()));
						gameOver = true;
					}
				}

				if (client.getPlayerInfo().getId() == 1)
				{
					if (rectPlayer2.getPosition().x >= pista2.getSize().x + 200)
					{
						client.sendMessage(std::to_string(Protocol::Win) + "_"
							+ std::to_string(client.getPlayerInfo().getId()));
						gameOver = true;
					}
				}
			}
			else
			{
				if (client.getP1Win())
				{
					txtPregunta.setString( "GANA EL JUGADOR 1");
					txtPlayer1Nick.setString("GANADOR Nick P1");
					txtPlayer2Nick.setString("PERDEDOR Nick P2");
				}
				else
				{
					txtPregunta.setString("GANA EL JUGADOR 2");
					txtPlayer1Nick.setString("PERDEDOR Nick P1");
					txtPlayer2Nick.setString("GANADOR Nick P2");
				}
			}
			window.draw(pista1);
			window.draw(pista2);
			window.draw(txtPlayer1Nick);
			window.draw(txtPlayer2Nick);
			window.draw(rectPlayer1);
			window.draw(rectPlayer2);

			window.draw(separator1);
			window.draw(separator2);

			window.draw(txtPregunta);

			std::string mensaje_ = mensaje + "_";
			text.setString(mensaje_);
			window.draw(text);

			if (!client.isConnected()) {
				window.close();
			}


			window.display();
			window.clear();
		}

	
}
/*
int main0(int argc, char const *argv[]) {

	Client client(sf::rec;

	if (client.connect()) {
		std::cout << "connection established" << std::endl;
	} else {
		std::cout << "connection error, " << std::endl;
	}

	sf::Vector2i screenDimensions(800, 600);

	sf::RenderWindow window;
	window.create(sf::VideoMode(screenDimensions.x, screenDimensions.y), "Client");

	while (window.isOpen()) {
		sf::Event evento;
		while (window.pollEvent(evento)) {
			switch (evento.type) {
			default:
				break;
			case sf::Event::Closed:
				client.disconnect();

				window.close();
				break;
			case sf::Event::KeyPressed:
			{
				// Start game
				if (evento.key.code == sf::Keyboard::Return) {
					client.sendMessage(std::to_string(Protocol::Start_Game));
				}

				if (evento.key.code == sf::Keyboard::Escape) {
					client.disconnect();

					window.close();
				}
			
			


					//Going left
				if (evento.key.code == sf::Keyboard::A)
					client.Move(Movements::Left);

				if (evento.key.code == sf::Keyboard::D)
					client.Move(Movements::Right);

				if (evento.key.code == sf::Keyboard::W)
					client.Move(Movements::Up);

				if (evento.key.code == sf::Keyboard::S)
					client.Move(Movements::Down);
				
			}
			break;
			case sf::Event::MouseButtonPressed:
				if (evento.key.code == sf::Mouse::Left)
					client.click(sf::Vector2f(evento.mouseButton.x, evento.mouseButton.y));
				break;
			

				
			}
		}

		client.receive();
		int posX = 0, posY = 0;
		for (int i = 0; i < DIMENSIONS; i++)
		{
			//30 + 7 +
			posX = i * screenDimensions.x / DIMENSIONS;
			for (int j = 0; j < DIMENSIONS; j++)
			{
				posY =  j * screenDimensions.y / DIMENSIONS;
				sf::RectangleShape rect;
				rect.setPosition(posX, posY);
				rect.setFillColor(sf::Color(0, 255, 0, 255));
				rect.setOrigin(sf::Vector2f(0,0));
				rect.setSize(sf::Vector2f(100, 100));
				rect.setOutlineColor(sf::Color(255, 250, 89, 255));
				rect.setOutlineThickness(2);
				window.draw(rect);
			}
		}
		client.draw(&window);
		

		window.display();
		window.clear();

		// Close the window if the client has gone
		if (!client.isConnected()) {
			window.close();
		}
	}
	client.disconnect();
	return 0;
}*/