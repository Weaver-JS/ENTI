#include "Grid2D.h"



Grid2D::Grid2D()
{
	for (int i = 0; i < DIMENSIONS; i++)
	{
		for (int j = 0; j < DIMENSIONS; j++)
		{
			grid[i][j] = false;
		}
	}
}


Grid2D::~Grid2D()
{
}

bool  Grid2D::getGridPos(int i,int j)
{
	return grid[i][j];

}

void Grid2D::setGridPos(bool f, int i, int j)
{
	grid[i][j] = f;
}
