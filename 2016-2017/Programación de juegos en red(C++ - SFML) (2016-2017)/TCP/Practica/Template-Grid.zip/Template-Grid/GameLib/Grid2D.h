#pragma once
#define DIMENSIONS 10
class Grid2D
{
	bool grid[DIMENSIONS][DIMENSIONS];
	int size;
public:
	Grid2D();
	~Grid2D();

	bool getGridPos(int i,int j);
	void setGridPos(bool f, int i, int j);
};

