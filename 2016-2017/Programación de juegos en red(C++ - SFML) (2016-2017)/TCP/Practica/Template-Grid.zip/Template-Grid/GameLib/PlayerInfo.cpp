#include "PlayerInfo.h"

PlayerInfo::PlayerInfo() {

	socket = new sf::TcpSocket();
	socket->setBlocking(true);
	circle = sf::CircleShape(20, size_t(30));
	circle.setOrigin(0, 0);
	circle.setPosition(position);
	circle.setFillColor(sf::Color(255, 0, 0, 255));
	circle.setOutlineColor(sf::Color(255, 0, 0, 255));
}

PlayerInfo::PlayerInfo(int id) {
	socket = new sf::TcpSocket();
	socket->setBlocking(true);
	this->id = id;
	position = sf::Vector2f(rand() % DIMENSIONS,rand() % DIMENSIONS);

	circle = sf::CircleShape(20, size_t(30));
	circle.setOrigin(0, 0);
	circle.setPosition(position);
	circle.setFillColor(sf::Color(255, 0, 0, 255));
	circle.setOutlineColor(sf::Color(255, 0, 0, 255));
}

PlayerInfo::~PlayerInfo() {
	socket->disconnect();
	delete socket;
}


sf::TcpSocket& PlayerInfo::getSocket() {
	return *socket;
}

void PlayerInfo::blocking(bool block) {
	socket->setBlocking(block);
}

int PlayerInfo::getId() { 
	return id;
}

std::string PlayerInfo::getPlayerInfo() {
	return std::to_string(id) + 
		"_" + std::to_string(position.x) + 
		"_" + std::to_string(position.y);
}

void PlayerInfo::setId(int id) {
	this->id = id;
}

void PlayerInfo::setPosition(sf::Vector2f pos) {
	position = pos;
}

void PlayerInfo::setColor(sf::Color color) {
	circle.setFillColor(color);
}

void PlayerInfo::draw(sf::RenderWindow* window) {

	circle.setPosition(50+ position.x * 800 / DIMENSIONS, 20 + position.y * 600 / DIMENSIONS);
	window->draw(circle);
}

sf::Vector2f & PlayerInfo::getPosition()
{
	if (position.x >= DIMENSIONS)
	{
		position.x = 0;
	}

	if (position.y >= DIMENSIONS)
	{
		position.y = 0;
	}

	if(position.x < 0)
	{
		position.x = (DIMENSIONS-1);
	}

	if (position.y < 0)
	{
		position.y = DIMENSIONS-1 ;
	}

	return position;
}
