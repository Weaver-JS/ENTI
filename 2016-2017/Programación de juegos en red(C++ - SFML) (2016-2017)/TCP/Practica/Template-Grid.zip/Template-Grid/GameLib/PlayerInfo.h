#pragma once
#include <SFML/Graphics.hpp>
#include <SFML/Network.hpp>
#include "Grid2D.h"
#include <sstream>
enum Movements 
{
	Right,
	Left,
	Up,
	Down
};

enum Protocol {
	Disconnect = 0,
	Hello = 1, // Server -> Client
	Position = 2,
	Start_Turn = 3,
	End_Turn = 4,
	Start_Game = 5,
	Word = 6,
	NiceJob = 7,
	Win = 8
};

class PlayerInfo
{
	std::string name;
	int id;
	sf::TcpSocket* socket;
	int lives;
	sf::Vector2f position;
	sf::CircleShape circle;

public:
	PlayerInfo();
	PlayerInfo(int id);
	~PlayerInfo();

	sf::TcpSocket& getSocket();

	void blocking(bool block);
	int getId();
	std::string getPlayerInfo();

	void setId(int id);
	void setPosition(sf::Vector2f pos);
	void setColor(sf::Color color);

	void draw(sf::RenderWindow* window);

	sf::Vector2f & getPosition();
};

class Utils {
	public:
	static std::vector<std::string> splitString(const std::string &line, char delim) {
		std::stringstream ssLine(line);
		std::string item;
		std::vector<std::string> tokens;
		while (getline(ssLine, item, delim)) {
			tokens.push_back(item.c_str());
		}
		return tokens;
	}

	static constexpr unsigned int str2int(const char* str, int h = 0) {
		return !str[h] ? 5381 : (str2int(str, h + 1) * 33) ^ str[h];
	}

};