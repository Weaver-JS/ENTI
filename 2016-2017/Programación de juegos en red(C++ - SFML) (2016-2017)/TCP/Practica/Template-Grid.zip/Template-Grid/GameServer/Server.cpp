#include "Server.h"

Server::Server()  :
     cmd(&Server::throwCommandLine, this),
     connections(&Server::throwNewConnections, this) {

     sMaxConnections = DEFAULT_MAX_CONNECTIONS;

	 words[0] = "Aprobar";
	 words[1] = "Examen";
	 words[2] = "Hola";
	 words[3] = "Hey";
	
}

Server::~Server() {}

/*
* Open server to receive connections,
     return false if the server can't listen
*/
bool Server::up() {
     if (sListener.listen(PORT) != sf::Socket::Done) {
          return false;
     }
     sIsRunning = true;

     cmd.launch();
     connections.launch();

	 playerInTurn = 0;
	 playerCount = 0;

     return sIsRunning;
}

bool Server::isRunning() {
     return sIsRunning;
}

void Server::update() {
     if (sCommand.compare("exit") == 0) {
          sIsRunning = false;
     }
}

void Server::throwNewConnections() {
     while (sIsRunning) {
		 // Close listen new players when game start
		 if (gameStarted) {
			 break;
		 }
		//sf::TcpSocket* socket = new sf::TcpSocket();
		PlayerInfo* newPlayer = new PlayerInfo(playerCount);

		newPlayer->blocking(true);

		sf::Socket::Status status = sListener.accept(newPlayer->getSocket());
		if (status == sf::Socket::Done ) {
			mtx.lock();
			newPlayer->blocking(false);
			if (players.size() < 2)
			{
				players.push_back(newPlayer);

				// Send Hello message ID, and position
				std::string message = std::to_string(Protocol::Hello) + "_" + newPlayer->getPlayerInfo();
				size_t sent = 0;
				std::cout << "send" << message << std::endl;

				newPlayer->getSocket().send(message.c_str(), message.length() + 1, sent);
				playerCount++;
				mtx.unlock();
				std::cout << "accepted new socket" << std::endl;
				std::cout << "new size of sockets " << players.size() << std::endl;
			}
		} else if (status == sf::Socket::Error ||
				status == sf::Socket::Disconnected) {
			std::cout << "received status "<< status  << std::endl;
			//delete socket;
			delete newPlayer;
		}
     }

	 // Close listener
	 sListener.close();
}

void Server::receive() {

	mtx.lock();

	for (int i = 0; i < players.size(); i++) {
		sf::Socket::Status status = players.at(i)->getSocket().receive(buffer, sizeof(buffer), received);
		// All sockets received
		switch(status) {
			case sf::Socket::Done:
				if (received > 0) {
					// Check what say the missage
					checkMessage(buffer);
				}
				break;
			case sf::Socket::Partial:
			break;
			case sf::Socket::NotReady:
			break;
			case sf::Socket::Disconnected:
			case sf::Socket::Error:
			break;
		}
	}
	mtx.unlock();
}


void Server::sendMessage(std::string message) {

	mtx.lock();
	sf::sleep(sf::milliseconds(250));
	std::cout << "send" << message << std::endl;
	for (int i = 0; i < players.size(); i++) {
		std::size_t sent = 0;
		sf::Socket::Status status;
		do {
			status = players.at(i)->getSocket().send(message.c_str(), message.length() + 1, sent);
		} while (status == sf::Socket::Partial);
	}
	mtx.unlock();
}

void Server::disconnectSocket(sf::TcpSocket& socket) {
     socket.disconnect();
     delete &socket;
}

void Server::disconnect() {
	sendMessage(std::to_string(Protocol::Disconnect));

	cmd.terminate();
	connections.terminate();

	for (int i = 0; i < players.size(); i++) {
		players.at(i)->getSocket().disconnect();
	}
	players.clear();

	sListener.close();

	std::cout << "disconnect" << '\n';
	sIsRunning = false;
}

void Server::throwWord()
{
	actualWord = (actualWord++) % (WORDSLENGTH-1);
	std::string endMessage = std::to_string(Protocol::Word) +
		"_" + words[actualWord];
	sendMessage(endMessage);

	// Pass to next player
	//playerInTurn++;
	gameTime.restart();
}

void Server::throwCommandLine() {
     std::string command;
     while(sIsRunning){
          std::cin >> command;
          mtx.lock();
          sCommand = command;
          mtx.unlock();
          command.clear();
     }
}

void Server::checkMessage(std::string received) {
	
	// Split
	std::vector<std::string> message = Utils::splitString(received, '_');
	if (message.size() <= 0) {
		return;
	}

	switch (std::stoi(message.at(0))) {
	case Protocol::Hello:
		std::cout << "hello" << std::endl;
		break;
	case Protocol::Disconnect:
	{
		std::cout << "protocol - disconnect: " << std::stoi(message.at(1)) << std::endl;
		int idReceived = std::stoi(message.at(1));

		// Check for the player that have the id received
		int pToRemove = -1;
		for (int i = 0; i < players.size(); i++) {
			if (players.at(i)->getId() == idReceived) {
				players.at(i)->getSocket().disconnect();
				pToRemove = i;
			}
		}
		if (pToRemove != -1){
			players.erase(players.begin() + pToRemove);
		}
		disconnect();
		std::cout << "new size of sockets " << players.size() << std::endl;
	}
	break;

	case Protocol::Win:
	{
		int idReceived = std::stoi(message.at(1));
		gameOver = true;
		
		sendMessage(std::to_string(Protocol::Win) + "_" + message.at(1));
	}
		break;
	case Protocol::Word:
	{
		std::cout << "Ha llegado" << std::endl;
		int idReceived = std::stoi(message.at(1));
		if (message.at(2) == words[actualWord])
		{

			std::string startMessage = std::to_string(Protocol::NiceJob) +
				"_" + std::to_string(idReceived);
			sendMessage(startMessage);
			actualWord = (actualWord++) % (WORDSLENGTH-1);
			sf::sleep(sf::milliseconds(250));
			std::string endMessage = std::to_string(Protocol::Word) +
				"_" + words[actualWord];
			sendMessage(endMessage);

			// Pass to next player
			//playerInTurn++;
			gameTime.restart();
			
		}
	}
		break;

	case Protocol::Start_Turn:
	
		std::cout << "start turn" << std::endl;	
		break;
	case Protocol::End_Turn:
		endTurn();
		startTurn();
		std::cout << "end turn" << std::endl;
		break;
	case Protocol::Position:
	{
		// Set the position arrived to the client
		std::cout << "pos" << std::endl;
		int id = std::stoi(message.at(1));
		sf::Vector2f pos = sf::Vector2f(std::stoi(message.at(2)),
			std::stoi(message.at(3)));
		for (int i = 0; i < players.size(); i++) {
			if (players.at(i)->getId() == id) {
				players.at(i)->setPosition(pos);
			}
		}
	}
		break;
	case Protocol::Start_Game:
		std::cout << "start Game" << std::endl;
		if (!gameStarted) {
			startGame();
		}
		break;
	}
	// Do something
}

void Server::startGame() {
	gameStarted = true;
	
	// Send all positions to all clients
/*	std::string message;
	for (int i = 0; i < players.size(); i++) {
		message = std::to_string(Protocol::Position) +
			"_" + players.at(i)->getPlayerInfo();
		sendMessage(message);
	}
	startTurn();*/
}

void Server::startTurn() {
	// Notify to all players what Player is in Turn
	int id;
	if (playerInTurn > players.size()-1) {
		playerInTurn = 0;
	}
	id = players.at(playerInTurn)->getId();

	std::string startMessage = std::to_string(Protocol::Start_Turn) +
		"_" + std::to_string(id);
	sendMessage(startMessage);

}

void Server::endTurn() {
	// Notify to all players the new position of the current player
	std::string endMessage = std::to_string(Protocol::Position) +
		"_" + players.at(playerInTurn)->getPlayerInfo();
	sendMessage(endMessage);

	// Pass to next player
	playerInTurn++;
	gameTime.restart();

}

void Server::updateGame() {
	if (!gameStarted) {
		return;
	}
	if (!gameOver)
	{
		if (gameTime.getElapsedTime() > sf::seconds(5.0f)) {
			throwWord();
			sf::sleep(sf::seconds(0.25f));
		}
	}

	else
	{
		sf::sleep(sf::seconds(1.0f));
		disconnect();
	}
}