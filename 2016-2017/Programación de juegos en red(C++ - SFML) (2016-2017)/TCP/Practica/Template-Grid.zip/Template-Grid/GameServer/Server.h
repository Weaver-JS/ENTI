#ifndef __SERVER
#define __SERVER

#include <list>
#include <string>
#include <iostream>

#include <SFML/Network.hpp>

#include  <PlayerInfo.h>

#define WORDSLENGTH 4
const int DEFAULT_MAX_CONNECTIONS =  4;
const int PORT = 5000;



class Server {
private:
	bool sIsRunning;
	bool gameOver = false;
	bool characterWon = false;
	int sMaxConnections;
	std::string words[WORDSLENGTH];

	sf::Thread cmd;
	sf::Thread connections;
	sf::Mutex mtx;

	sf::TcpListener sListener;

	std::vector<PlayerInfo*> players;

	std::string sCommand;

	char buffer[2000];
	std::size_t received;
	std::size_t sent;
	// For id
	int playerCount;
	
	// Game variables
	int playerInTurn;
	int actualWord;
	bool gameStarted = false;
	sf::Clock gameTime;

public:
     Server();
     ~Server();

     bool isRunning();

     void throwCommandLine();
     void throwNewConnections();

     bool up();
     void update();
	 void checkMessage(std::string message);

     void receive();
	 void sendMessage(std::string message);

	 void startGame();
	 void startTurn();
	 void endTurn();
	 void updateGame();

     void disconnectSocket(sf::TcpSocket& socket);
     void disconnect();

	 void throwWord();
};

#endif
