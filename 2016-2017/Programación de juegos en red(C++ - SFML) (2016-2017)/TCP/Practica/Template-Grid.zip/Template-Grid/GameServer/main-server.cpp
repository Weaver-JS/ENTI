#include "Server.h"

int main(int argc, char const *argv[]) {
     Server server;

	 // Connect the Server
     if (server.up()) {
          std::cout << "server is up" << std::endl;
     } else {
          std::cout << "server can not connect" << '\n';
     }
     while(server.isRunning()) {
		// receive
		server.receive();
		// send

		server.updateGame();
    }
     server.disconnect();

     return 0;
}
