Noms:
Alex Torrents
Jose Su�rez

Links:
Pixelizaci�n - https://www.shadertoy.com/view/lslczl
Tonemapping - https://www.shadertoy.com/view/ldlyRs
Vignetting - https://www.shadertoy.com/view/lssyzs
Correcci�n de Gamma - https://www.shadertoy.com/view/4dXcWS
Separable Blur -  https://www.shadertoy.com/view/4sXcWS
Bloom - https://www.shadertoy.com/view/4sfcWS#
